package algorithms.mazeGenerators;
import java.util.Random;

public class SimpleMazeGenerator extends AMazeGenerator {

    @Override
    public Maze generate(int rows, int columns) {

        int[][] maze = new int[rows][columns];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < columns; j++)
                maze[i][j] = 0;

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < columns; j++)
                maze[i][j] = new Random().nextInt(2); // 0 to 1


        int start1 = 0;
        int start2 = new Random().nextInt(columns);
        Position start = new Position(start1, start2);

        int goal1 = rows - 1;
        int goal2 = new Random().nextInt(columns);

        while (start2==goal2)
            goal2 = new Random().nextInt(columns);

        Position goal = new Position(goal1, goal2);

        return new Maze(maze, rows, columns, start, goal);
    }
}