package Server;

public class Configurations {
}
