package algorithms.mazeGenerators;

import java.util.Random;

public class EmptyMazeGenerator extends AMazeGenerator{

    @Override
    public Maze generate(int rows, int columns) {
        //maze
        int[][] EmptyMaze = new int[rows][columns];
        for (int i = 0; i < rows; i++){
            for (int j = 0; j < columns; j++){
                EmptyMaze[i][j] = 0;
            }
        }

        //start
        int start1 = new Random().nextInt(rows);
        int start2 = new Random().nextInt(columns);
        Position start = new Position(start1,start2);

        //goal
        int goal1 = new Random().nextInt(rows);
        int goal2 = new Random().nextInt(columns);

        while(start1==goal1 || start2==goal2)
        {
            goal1 = new Random().nextInt(rows);
            goal2 = new Random().nextInt(columns);
        }

        Position goal = new Position(goal1,goal2);

        //return maze
        return new Maze(EmptyMaze, rows, columns, start, goal);
    }
}
